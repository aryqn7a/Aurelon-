import { supabase } from '../lib/supabase'
const IMG = { 'image/png': 'png', 'image/jpeg': 'jpg', 'image/webp': 'webp' }
const VID = { 'video/mp4': 'mp4', 'video/webm': 'webm' }
// Uploads one file to the public "portfolio" bucket and returns its public URL.
// Images: PNG/JPG/WebP up to 5 MB. Videos: MP4/WebM up to 50 MB. The bucket and database policies also enforce admin-only uploads.
export async function upload(file, video = false) {
  const ext = (video ? VID : IMG)[file.type]
  if (!ext) throw new Error(video ? 'Only MP4 or WebM videos are allowed.' : 'Only PNG, JPG or WebP images are allowed.')
  if (file.size > (video ? 50 : 5) * 1024 * 1024) throw new Error(video ? 'Videos must be 50 MB or smaller.' : 'Images must be 5 MB or smaller.')
  const path = `${crypto.randomUUID()}.${ext}`
  const { error } = await supabase.storage.from('portfolio').upload(path, file, { contentType: file.type })
  if (error) throw error
  return supabase.storage.from('portfolio').getPublicUrl(path).data.publicUrl
}
