import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import Projects from './Projects.jsx'
const IDLE_MS = 30 * 60 * 1000
function Dashboard() {
  const [c, setC] = useState(null)
  useEffect(() => {
    const q = (t, f) => { const r = supabase.from(t).select('*', { count: 'exact', head: true }); return f ? f(r) : r }
    Promise.all([q('projects'), q('projects', (r) => r.eq('status', 'published')), q('projects', (r) => r.eq('status', 'draft')),
      q('inquiries', (r) => r.eq('status', 'New')), q('applications', (r) => r.eq('status', 'Pending'))]).then((r) => setC(r.map((x) => x.count ?? 0)))
  }, [])
  const L = ['Total projects', 'Published', 'Drafts', 'New inquiries', 'Pending applications']
  return (<div><h2>Dashboard</h2><div className="stats">{L.map((l, i) => <div className="card pad" key={l}><b>{c ? c[i] : '-'}</b>{l}</div>)}</div>
    <p className="muted" style={{ marginTop: 24 }}>Inquiries and applications are saved privately. Until their admin screens are added, review them in Supabase under Table Editor.</p></div>)
}
export default function AdminApp() {
  const [st, setSt] = useState('loading'), [tab, setTab] = useState('dash'), [err, setErr] = useState('')
  const check = async (session) => {
    if (!session) return setSt('out')
    const { data } = await supabase.from('admins').select('user_id').eq('user_id', session.user.id).maybeSingle()
    if (data) setSt('in')
    else { await supabase.auth.signOut(); setErr('This account is not authorised for the admin panel.'); setSt('out') }
  }
  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => check(data.session))
    const { data: l } = supabase.auth.onAuthStateChange((ev) => { if (ev === 'SIGNED_OUT') setSt('out') })
    return () => l.subscription.unsubscribe()
  }, [])
  useEffect(() => { // sign out after 30 minutes without activity
    if (st !== 'in') return
    let t; const reset = () => { clearTimeout(t); t = setTimeout(() => supabase.auth.signOut(), IDLE_MS) }
    const ev = ['click', 'keydown', 'mousemove']; ev.forEach((e) => addEventListener(e, reset)); reset()
    return () => { clearTimeout(t); ev.forEach((e) => removeEventListener(e, reset)) }
  }, [st])
  const login = async (e) => {
    e.preventDefault(); setErr('')
    const f = new FormData(e.target)
    const { data, error } = await supabase.auth.signInWithPassword({ email: f.get('email'), password: f.get('password') })
    if (error) setErr('Invalid email or password.'); else check(data.session)
  }
  if (st === 'loading') return <div className="adm"><p className="muted">Loading...</p></div>
  if (st === 'out') return (<div className="adm" style={{ maxWidth: 420 }}><h2>Admin login</h2>
    <form onSubmit={login}><label>Email<input name="email" type="email" required autoComplete="username" /></label>
      <label>Password<input name="password" type="password" required autoComplete="current-password" /></label>
      {err && <p className="err" role="alert">{err}</p>}<button className="btn">Log in</button></form>
    <p style={{ marginTop: 24 }}><Link to="/" className="muted">Back to website</Link></p></div>)
  return (<div className="adm"><div className="row" style={{ justifyContent: 'space-between', marginBottom: 24 }}>
    <div className="row"><button className={'chip' + (tab === 'dash' ? ' on' : '')} onClick={() => setTab('dash')}>Dashboard</button>
      <button className={'chip' + (tab === 'proj' ? ' on' : '')} onClick={() => setTab('proj')}>Portfolio</button></div>
    <button className="btn ghost sm" onClick={() => supabase.auth.signOut()}>Log out</button></div>
    {tab === 'dash' ? <Dashboard /> : <Projects />}</div>)
}
